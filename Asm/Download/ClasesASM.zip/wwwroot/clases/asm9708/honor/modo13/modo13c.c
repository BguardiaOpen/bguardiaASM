

extern InicializaModoGrafico();
extern getch();
extern putc(char c);
extern CierraModoGrafico();
extern DibujaPunto(int x,int y,int color);
extern LineaVertical(int address, int d_y, int color, int offset);
extern LineaHorizontal(int address, int d_x, int color);
extern XLinea(int d, int d_x, int incr1, int incr2, int yinc, int direccion, int color);
extern YLinea(int d, int d_y, int incr1, int incr2, int xinc, int direccion, int color, int offset);
extern int RegresaColorPixel(int x, int y);
extern circulo(int radio,int x_c, int y_c, int color);
extern linea(int x1,int y1,int x2, int y2, int color);
extern barra(int x1,int y1,int x2, int y2, int color);
extern rectangulo(int x1, int y1, int x2, int y2, int color);
extern circuloRelleno(int radio, int x, int y, int color);
extern relleno(int x, int y, int color, int colorlimite);


void main()
{
	int x,i;

	InicializaModoGrafico();
	linea(10,80,80,20,9);
	DibujaPunto(75,130,4);
	DibujaPunto(77,131,5);
	DibujaPunto(74,132,45);
	DibujaPunto(75,134,57);
	DibujaPunto(75,139,49);
	DibujaPunto(79,130,44);
	DibujaPunto(82,131,12);
	DibujaPunto(81,132,45);
	DibujaPunto(74,134,60);
	DibujaPunto(81,145,83);
	DibujaPunto(79,139,138);
	DibujaPunto(82,133,210);
	DibujaPunto(81,134,200);
	DibujaPunto(74,132,134);
	DibujaPunto(81,141,63);
	DibujaPunto(85,130,4);
	DibujaPunto(87,131,5);
	DibujaPunto(84,132,45);
	DibujaPunto(85,134,57);
	DibujaPunto(85,139,49);
	DibujaPunto(89,130,44);
	DibujaPunto(86,131,12);
	DibujaPunto(87,132,45);
	DibujaPunto(84,134,60);
	DibujaPunto(91,145,83);
	DibujaPunto(79,142,138);
	DibujaPunto(82,143,210);
	DibujaPunto(81,144,200);
	DibujaPunto(74,142,134);
	DibujaPunto(81,151,63);


	circulo(35,159,99,4);
	circulo(10,124,64,6);
	rectangulo(20,30,34,67,7);
	barra(135,87,189,150,9);
       // circulo(20,200,170,10);
       // relleno(200,170,10,10);
	linea(90,100,130,150,150);
	linea(70,30,120,30,4);
	rectangulo(30,180,90,199,10);
	circulo(15,270,50,17);
	relleno(270,50,17,17);
	barra(20,100,70,130,35);
	circulo(24,240,150,42);
	relleno(240,150,42,42);
	linea(40,156,78,190,44);
	linea(30,130,52,160,49);
	barra(200,10,250,45,44);
	circulo(20,140,60,56);
	circulo(20,150,60,49);
	circulo(20,160,60,66);
	barra(260,170,300,190,41);
	rectangulo(236,80,315,144,39);
	linea(300,100,270,150,52);
	linea(40,20,80,70,52);
	barra(50,32,73,110,57);
	circulo(33,30,56,44);
	rectangulo(70,120,130,160,65);
	circulo(23,45,160,68);
	relleno(45,160,73,68);
	barra(270,150,330,165,70);
	circulo(30,159,170,79);
	circulo(23,159,170,4);
	relleno(159,170,4,4);
	barra(290,30,318,45,57);
	circulo(19,149,30,48);
	relleno(149,30,48,48);
	linea(80,89,159,50,44);
	linea(240,60,301,130,4);
	linea(220,80,290,100,47);
	circulo(16,260,60,57);
	relleno(260,60,57,57);
	linea(65,60,80,100,65);
	linea(80,100,95,60,65);
	linea(95,60,65,60,65);
	relleno(70,61,34,65);
	linea(220,70,210,100,140);
	linea(210,100,240,110,140);
	linea(240,110,230,140,140);
	linea(230,140,270,120,140);
	linea(270,120,290,100,140);
	linea(290,100,270,80,140);
	linea(270,80,240,90,140);
	linea(240,90,220,70,140);
	relleno(270,100,140,140);

       for (x=0; x<=320; x+= 24)
       {
	for (i=20;i<=31; i++)
	{
	 linea(x,0,x,199,i);
	 x++;
	}
	for (i=31; i>=20; i--)
	{
	 linea(x,0,x,199,i);
	 x++;
	}
       }
	       
	getch();
	CierraModoGrafico();

}
