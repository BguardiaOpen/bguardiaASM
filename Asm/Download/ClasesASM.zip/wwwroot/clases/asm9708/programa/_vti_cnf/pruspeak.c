vti_encoding:SR|utf8
vti_extenderversion:SR|3.0.1.726
vti_author:SR|bguardia
vti_modifiedby:SR|DOMSINERGIA\BGUARDIA
vti_timecreated:TR|15 Aug 1997 11:25:40 -0500
vti_nexttolasttimemodified:TR|15 Aug 1997 11:25:40 -0500
vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Aug 1997 11:25:40 -0500
vti_backlinkinfo:VX|asm9708/refer.htm asm9708/clase21.htm
